---
tags:
- sentence-transformers
- sentence-similarity
- feature-extraction
- dense
- generated_from_trainer
- dataset_size:4589
- loss:CosineSimilarityLoss
base_model: sentence-transformers/all-MiniLM-L6-v2
widget:
- source_sentence: Career OverviewHighly motivated Sales Associate with extensive
    customer service and sales experience. Outgoing sales professional with track
    record of driving increased sales, improving buying experience and elevating company
    profile with target market. QualificationsDatabases File SystemsOracle , MS AccessNetezzaHadoop
    Big DataAmazon Redshift , S3Software ProductsOracle D2K, Forms Reports 10gOracle
    Apps 11gHadoop Impala Hive SparkAmazon Web services, Redshift Programming LanguagesOracle
    PL SQL SQL, Impala SQLPythonJava(Basics), CVisual Basic, Coding in MS Excel using
    VBA, Power QueryUnix VMSSoftware ToolsPL SQL Developer, TOAD, DB Visualizer, NPS
    Admin tool Aginity for Netezza RedshiftForm Report BuilderElastic Search, Logstash
    and KibanaCloudwatch Exports to excelEclipse, PyCharmMS Office, MS Project. MS
    Visio, Power Query with ExcelPutty, Attachmate Reflection,HPSD, Remedy, Service
    PointNSI, VSS, IBM Rational Clear Case Clear Quest, Tortoise SVN, GitHubHP Quality
    Center , JIRAHadoop Hue, Cloudera ManagerThe details of the various assignments
    that I have handled are listed here, in chronological order.01 - T-MSIS (Transformed
    Medicaid Statistical Information System)Client Centers for Medicare and Medicaid
    Services (CMS)Location Windsor Mill, MarylandDuration 09 2015-Till dateRole Technical
    Analyst Senior Developer Architect Data AnalystSolution Environment Oracle 11g,
    Informatica, UNIX, Amazon Web Services (AWS), Redshift Work ExperienceTeam Lead
    Senior Developer Architect Data Analyst,06 2014-08 2015Exela Technologies Inc.
    Stamford,CT,9.2 years of extensive experience in business analysis, system analysis,
    design, development and Implementation of various projects with strong experience
    in Database system and Project management.Good knowledge of Hadoop ecosystems,
    HDFS, AWS, Netezza, Oracle, Hive, Sqoop, Impala and Amazon Redshift.Implemented
    Proof of concepts on running Hadoop, migration from multiple databases (Netezza,
    Oracle) to Hadoop.Experience in working with different data sources like Flat
    files, XML files and Databases Key participant in all phases of the SDLC ranging
    from requirement analysis design, development and testing (unit, system, integration,
    Regression, Product).Ability to design database schemas, performance tunes SQLs,
    troubleshoot, improve logic and move data through the enterprise.Experience in
    writing complex SQL queries involving multiple tables inner and outer joins.Experience
    in Creating Tables, Views, Triggers, Stored Procedures, User Defined Functions
    and other SQL statements for various applications.Streamlined SQL, improved speed
    via query optimization, modified tables, and enhanced metrics Maintain accurate
    and organized notes on the status of development projects.Experienced in Application
    development Implementation.Agile Waterfall Software Development Model Client-onsite,
    Client - Offshore and Onsite-Offshore model Change Management, Incident Problem
    Management Supply Chain Management System ( Transportation and Warehousing) Media
    Research - Nielsen Media research.Project management, Agile Scrum Master.Team
    Lead Senior Developer Data Analyst,05 2012-05 2014Perspecta Inc. Miami,FL,IndiaSolution
    Environment Oracle 11g, Netezza (7.0.2), TIBCO, UNIX Responsibilities Analysis
    and Design, Development Implementation of Software solutions Team Handling, Software
    Estimation Impact Analysis.Evaluated business requirements and prepared detailed
    specifications that follow project guidelines required to develop written programs
    Involved in loading data from UNIX file system to Netezza Analyzed the data by
    performing Netezza queries and reviewed the results with data science team.Revised
    procedures that solve complex business problems with due considerations for hardware
    software capacity and limitations, operating times and desired results.Analyzed
    large amounts of data sets to determine optimal way to aggregate and report on
    it.Provided quick response to ad hoc internal and external client requests for
    data and experienced in creating ad hoc reports.RFCs, Change Management and Version
    control.Review of code and Test scenarios.Maintenance Support of Existing Software
    applications, Status reporting 04 - IKEA Cargo Network Systems.Service Delivery
    Manager,05 2009-04 2012IKEA IT City,,GermanyOracle 10g, D2K, Forms 10g, Open VMS
    Responsibilities Service Delivery Management Incident, Problem and Change Management.Analysis
    and Design Implementation of Changes identified in support.Ensuring On-time delivery
    (OTD), First Time Right (FTR).Ensuring E2E application is up and Running (24 7)
    Status reporting 05 - Job-Jar GE Oil Gas.Software Developer,05 2007-04 2009GE
    Oil Gas City,,IndiaOracle 10g, D2K, UNIX, Apps (11.) Responsibilities Analysis
    and Design, Development Implementation of Change Requests.RFCs, Change Management
    and Version Control.Software Estimation Impact Analysis.Ensuring On-time delivery
    (OTD), First Time Right (FTR).Requirement analysis and technical design document
    creation.Involved in developing changing modules as per Technical design documents.SQL-Query
    Tuning Created indexes on selective columns to speed up queries and Enhanced performance
    using optimization techniques-normalization, indexing and Transaction Isolation
    levels, monitoring logs to ensure the completeness of batch processes and scripts.Designed
    and developed SQL stored procedures to replace existing business logic.Development
    of indexing schemes for most efficient insert, update and select Involved in system
    testing Integration testing Status reporting. Education and TrainingBachelor of
    technology Computer Science and Engineering,Expected in--,GPA Status-Computer
    Science and EngineeringB.Tech - CSE ,Expected in2006-Mahatma Gandhi University-,Kerala.GPA
    Status-Degree ,Expected in2001-Mahatma Gandhi University Board of Secondary Education-,KeralaGPA
    Status- Skillsad, Agile, Analyst, Application development, Architect, automation,
    Big Data, business analysis, C, Change Management, CMS, hardware, Network Systems,
    Client, Version Control, Data Analyst, Data Analysis, data modeling, Databases,
    Data base, Database, Delivery, Eclipse, XML, Forms, FTP, HP, IBM, indexing, Informatica,
    Java, leadership, logic, notes, Managing, Meetings, MS Access, MS Excel, Excel,
    MS Office, MS Project, Migration, Mill, enterprise, Oil, Open VMS, optimization,
    Oracle, DB, Developer, Oracle PL SQL, PL SQL, processes, Coding, Programming,
    Project lead, Project management, Python, Quality, QA, Quest, quick, reporting,
    Requirement, Research, Scrum, SDLC, Set top Box, scripts, Software Development,
    SQL, strategy, structured, Supply Chain Management, system analysis, Tables, team
    player, TIBCO, TOAD, Transportation, troubleshoot, UNIX, Visio, Visual Basic,
    VBA, Visualizer, VMS, Warehousing, written, written communication skills
  sentences:
  - At Meraki, were making IT easier, faster, and smarter. Our full-stack teams build
    and maintain our web application, which manages millions of network devices from
    our cloud. Our customers use the Meraki dashboard to monitor and configure critical
    IT infrastructure that serves tens of millions of people every single day. As
    a Meraki Full Stack Engineer, you will collaborate with firmware engineers to
    design, plan, and build new features for our customers. With the help of product
    managers and UX designers, you will construct intuitive and powerful workflows
    to solve important problems for IT professionals around the world. Merakis product
    Dashboard teams are small, fast-moving teams striving to make our products unique
    in balancing their feature-rich abilities and their simplicity. Youll be developing
    the tools by which our customers configure and monitor network devices all over
    the world. Our full-stack engineers are well versed in a wide array of CS concepts
    and excited to jump around languages, platforms, and all levels of the Meraki
    stack! What you will do Developing the tools by which our customers configure
    and monitor network devices all over the world. Collaborate with firmware engineers
    to design, plan, and build new core product features for our customers. With the
    help of product managers and UX designers, you will construct intuitive and powerful
    workflows to solve important problems for IT professionals around the world. Responsible
    for crafting and building some of the high-impact technology projects. Involved
    in resolving some of the complex scale-related problems Accountable for the stability
    of our product with a high customer focus. Share your knowledge by giving brown
    bags, tech talks, and evangelizing engineering standard methodologies. You are
    an ideal candidate if you Have 5 years of experience writing professional production
    codeHave 3 years of experience in building rich web UIs with React (and Redux),
    Javascript, Java or similar frameworksHave 3 years of experience in web backend
    technologies, like Ruby on RailsCan implement good database design in a relational
    database (we use Postgres). Have experience with customer-centric designWould
    thrive on a small engineering team and are excited to solve open-ended problems
    across the stack. Are interested in career advancement. Were looking for leaders,
    whether that means you want to be a strong leading individual contributor or you
    want to grow into a tech lead roleBonus points for any of the following Experience
    or interest in networkingExperience building cloud-based infrastructure and services
    (e.g. web applications). Cisco is an Affirmative Action and Equal Opportunity
    Employer and all qualified applicants will receive consideration for employment
    without regard to race, color, religion, gender, sexual orientation, national
    origin, genetic information, age, disability, veteran status, or any other legally
    protected basis. At Cisco Meraki, were challenging the status quo with the power
    of diversity, inclusion, and collaboration. When we connect different perspectives,
    we can imagine new possibilities, inspire innovation, and release the full potential
    of our people. Were building an employee experience that includes appreciation,
    belonging, growth, and purpose for everyone.
  - Experienced Business Analyst in Telecom PromosAnalyze promo defect data and create
    analyses summarize as specified.Root cause analysesPreparation of training materials.Support
    process definitionDocumentation
  - Role - Business Analyst - Mobile Location - Louisville, KY (Onsite) Responsibilities
    Evaluating business processes, anticipating requirements, uncovering areas for
    improvement, and developing and implementing solutions. Leading ongoing reviews
    of business processes and developing optimization strategies. Staying up-to-date
    on the latest process and IT advancements to automate and modernize systems. Conducting
    meetings and presentations to share ideas and findings. Performing requirements
    analysis. Documenting and communicating the results of your efforts. Effectively
    communicating your insights and plans to cross-functional team members and management.
    Gathering critical information from meetings with various stakeholders and producing
    useful reports. Working closely with clients, technicians, and managerial staff.
    Providing leadership, training, coaching, and guidance to junior staff. Allocating
    resources and maintaining cost efficiency. Ensuring solutions meet business needs
    and requirements. Performing user acceptance testing. Managing projects, developing
    project plans, and monitoring performance. Updating, implementing, and maintaining
    procedures. Prioritizing initiatives based on business needs and requirements.
    Serving as a liaison between stakeholders and users. Managing competing resources
    and priorities. Monitoring deliverables and ensuring timely completion of projects.
    Requirements A bachelor s degree in ITComputer Science or related field or an
    MBA. 10 years of experience in business analysis or a related field. Exceptional
    analytical and conceptual thinking skills. The ability to influence stakeholders
    and work closely with them to determine acceptable solutions. Advanced technical
    skills. Excellent documentation skills. Fundamental analytical and conceptual
    thinking skills. Experience creating detailed reports and giving presentations.
    Competency in Microsoft applications including Word, Excel, and Outlook. A track
    record of following through on commitments. Excellent planning, organizational,
    and time management skills. Experience leading and developing top-performing teams.
    A history of leading and supporting successful projects.
- source_sentence: SummaryI am highly motivated, hardworking individual with over
    2 solid years experience in accounting.Results-oriented skilled in accounting
    operations and who effectively manages strict deadlines, schedules and repetitive
    tasks with a positive, can-do attitude. I am seeking a position in your organization
    where I can bring immediate value and strengths whilst developing my current skills
    further. HighlightsGeneral and tax accountingAccount reconciliationsStrong organizational
    skillsComputer proficiency (PC and Mac)Financial statement analysisAnalytical
    reasoningEffective time managementFlexible team player EducationKaplan UniversityDavenport,IAExpected
    in2013 Master of Science Accounting-GPA GPA 3.95Emphasis in AuditingUnited States
    International University-AfricaNairobi,KEExpected in2001 Bachelor of Science International
    Business Administration-GPA Emphasis in Accounting,IAExpected in -GPA ExperienceGraphic
    Packaging-Accountant IIVisalia,CA,10 2013-05 2015Responsible for verifying and
    post detailed business transactions to general ledger through FASKB system in
    support of the day-to-day operations. Also balance and audit general ledger accounts
    and prepare accounting entries as needed.Responsible for maintaining investment
    program and subsidiary ledgers for the partnership investments. Maintain amortization
    schedule and calculate and post interest accrual payments. Balance general ledger
    to investment subsidiary ledger.Provides support in preparing various reports
    which summarize and forecast the bank s business activity and financial position
    in areas of assets, liabilities, income, expenses, and earnings based on past,
    present, and expected operations.Work with the tax department in preparation of
    sales Use Tax reconciliation report to reconcile general ledger balances with
    main account balances and resolve any difference s and also responsible for filing
    state business license renewals for mortgage bank branches .Review and analyze
    balance sheet account reconciliations for example cash accounts (demand deposits)Prepare
    and post journal entries inter company bank transactions in the accounting system.Participate
    in month-end close process.Develop and maintain strong working relationships with
    stakeholders at all levels.Assisting the shared service Controller with various
    tasks, including audits undertook the task of preparing quarterly consolidation
    of inter-company recons for SunTrust Trust Partnerships and Entities loans and
    AR balances for external auditors with zero error as of to date. Worked with internal
    auditors and EY in providing supporting documentation and participate in audit
    walk through.Elior-Revenue AccountantBerkeley,IL,2012-09 2013Reviewed, analyzed,
    and accounted for tuition and revenue at assigned schools.Performed month end
    responsibilities including monthly closing process for up to 10 domestic schools,
    post-close number analysis, accruing of expenses and research of Profit and Loss
    variances.Worked with field personnel to ensure accuracy of sub ledger postings
    and compliance with GAAP and company policies.Completed monthly balance sheet
    reconciliations and maintained proper documentation.Researched and resolved reconciliation
    items through communication with various departments.Completed various ad hoc
    reports and projects assigned by management.Preparing monthly journal entries
    and posting via oracle and monitoring accounting records for multiple cost centers
    to ensure GAAP compliance.Prepared and processed inter-company invoices, travel
    expense and reimbursement requests for the department.To eliminate discrepancies
    and ensure vendor payments are accurate and paid on time created an AP submission
    invoice tracking sheet.University Of California-Financial Aid OfficerBrisbane,CA,03
    2009-2012Calculate student tuition , book charges and post to student general
    ledger account using CampusVue and then post title IV federal funds) payments
    to student ledger accounts.Ensure data entry is complete and accurate.Approve
    and initiate Title Iv and Non-Title Iv funds while monitoring disbursements eligibility
    is met based on federal and institutional policies.Run cash flow and remaining
    balance reports weekly for multiple campuses and monitor their AR to ensure all
    funds are paid accurately and on schedule through use of strong analytical skills
    to review and resolve issues.Perform as well as resolve reconciliations of federal
    loans and grants providing explanations.Manually import and export batches of
    Title IV Non-Title IV funds files containing cash disbursements daily and review
    all incoming and outgoing batches for accuracy, completeness and to resolve possible
    rejections.General ledger accounting Flexible team player. Skills
  sentences:
  - ARM GROUP is looking for a Senior Electrical Engineer for our growing Client located
    in Annapolis, Maryland. The candidate will be responsible for the management of
    the electrical staff, quality control, project management, and review of design
    and construction documents. Additionally, the candidate will assist with the process
    and instrumentation diagrams (P IDs), and instrumentation amp control implementation.
    Responsibilities of this position during the design and construction phases of
    projects include Power Distribution, Motor Control, PLC Control System, Control
    Panels, Lighting, Facility Conduit and Wiring DesignSchematic and Logic DevelopmentExtensive
    Knowledge and Implementation of the National Electric CodeWorking knowledge of
    AutoCADFacility Construction Document and Shop Drawing ReviewFacility Testing
    and Startup As a successful candidate you should have Minimum 6 years experience
    in Industrial Electrical Design, preferably in water and wastewater applicationProfessional
    Engineer license in Maryland or ability to obtainProject Management experienceQuality
    focus with attention to detail ARM Group LLC is an Equal Employment Opportunity
    Employer. All qualified applicants will receive consideration for employment without
    regard to race, color, religion, gender identity, sexual orientation, national
    origin, genetic information, sex, age, disability, veteran status, or any other
    legally protected basis. The ARM GROUP LLC welcomes and encourages applications
    from diverse candidates, including people with disabilities. Accommodations are
    available upon request for applicants taking part in all aspects of the selection
    process. Applicants for this position must be legally authorized to work in the
    United States.
  - Position Title Senior Accountant Organization Jewish Family Service of San Diego
    Department Family and Community Services Division Organization Jewish Family Service
    of San Diego Position Type Full-Time (37.5 hoursweek), Exempt Salary 82,000 -
    88,000year Total Compensation In addition to standard pay, compensation for this
    position includes Comprehensive, low-cost healthcare coverage for employees Generous
    employer 401(k) contributions Employer-covered life insurance Time Away from Work
    Being able to take time away from work is critical in bringing your best self
    to work. Time off benefits for this position include Generous paid vacation time
    and sick leave 17 paid holidays, including Federal, Jewish, and floating holidays
    2 Wellness Days to be taken any time during the year to support employees mental
    wellness Position Overview The Senior Accountant is an integral part of the financial
    planning function within the Finance Accounting Team. The position works closely
    with a range of departments and programs, including program directors and senior
    staff. The candidate must be a self-starter who is diligent, proactive, detail
    oriented, and is expected to contribute significantly to the Finance Accounting
    Team. Under the direction of the Senior DirectorController this position will
    support the Agency fiscal operations through transactional processing, financial
    analysis, annual budget development and monitoring, cost allocation, monthly forecasts,
    program and annual audit support, and the implementation of financial and compliance
    controls. The Senior Accountant will serves as a key resource for the organization
    and provides daily financial oversight to ensure that the financial records are
    complete, accurate, and comply with generally accepted accounting principles,
    policies, and regulations to facilitate solid decision support. Responsibilities
    Deliver monthly financial reporting, analytics and insight on performance metrics,
    benchmarking progress against targets, initiatives, and strategies Conduct analytical
    reviews for departmental and programmatic activities to support complex financial
    and budgetary forecasting evaluates alternatives and makes recommendations Develop
    an understanding of organization wide departments and programs funding streams
    andor cost structure Assist with analysis used for decision-making and recommendations
    to management and programs Analyze financial operational results to understand
    and report underlying causes for performance and variance Assist with the agency
    budgeting and forecasts scenario planning based on changing assumptions in revenue,
    personnel, and other direct project costs Perform budget to actual variance analysis
    to identify causes, adjustments needed, trends, personnel reclassifications, potential
    budget shortfalls or cost overruns, and opportunities for cost savings Assist
    with weekly cashflow management reports and projections Prepare monthly, quarterly,
    annual and ad-hoc financial statements with actual and projected financial positions
    Ensure the integrity of key processes by understanding systems, flow of transactions,
    internal controls, and recommending efficiency and effectiveness improvements
    Work with the Finance Accounting team to identify areas or opportunities for improvement
    Support organizational and management practices as applied to the analysis, evaluation,
    development, and implementation of programs, policies, and procedures Perform
    variance analyses and account reconciliations as needed Assist with month end
    closing, year-end closing and reconciliations and preparation for the external
    audit and prepare necessary audit schedules as needed Ad Hoc requests and one-off
    projects and other duties as assigned SkillsExperienceAbilities That Are a Must-Have
    Bachelor s degree in Accounting or Finance is required Minimum 8 years accounting
    experience with progressive and relevant and analytical budgeting, analysis, and
    reporting experience Minimum 5 years in the nonprofit industry Knowledge and understanding
    of cost methodologies, budgeting concepts, practices, and procedures, and accounting
    competencies, including an understanding of revenue recognition Understanding
    of GAAP compliance and Uniform Guidance and OMB Circulars Excellent written and
    verbal communication and interpersonal skills Strong analytical, organizational
    and time management skills Work well in a team approach environment Demonstrably
    strong judgement and decision-making skills Ability to multi-task and prioritize
    workflow Advanced in Excel and proficient Word and Outlook SkillsAbilities wed
    like you to Have Desire to work in a fun, friendly, collaborative, and professional
    environment Passion for working in a non-profit, human services organization dedicated
    to helping individuals in need Experience with Financial Edge not required but
    preferred Important Notice Incomplete submissions will not be considered. Please,
    no phone calls. Please, principals only. Please, local candidates only (relocation
    is not provided). About Jewish Family Service of San DiegoJewish Family Service
    of San Diego is a client-centered, impact-driven organization working to build
    a stronger, more resilient community. For over 100 years, Jewish Family Service
    has been a trusted resource for the entire community, offering an array of services
    that are always life-changing, and often life-saving. At Jewish Family Service,
    we believe our employees are the backbone of our Agency. We strive to ensure that
    each employee is treated with dignity and respect. Our goal is your success. Come
    work at JFS and be our partner in Moving Forward Together. To learn more about
    JFS, please visit jfssd.org. Jewish Family Service is an equal opportunity employer.
    All applicants will be considered for employment without attention to race, color,
    religion, sex, sexual orientation, gender identity, national origin, veteran or
    disability status.
  - Pay Range 81k - 102k, depending on experience.This role is responsible for creating
    and maintaining functional, responsive, accurate ERP product configuration software
    applications. Key areas of responsibility include creating new BOM structures
    and machine interfaces, creating solutions to changing business requirements,
    trainingadvising team members on best practices, troubleshooting Sales Order Entry,
    BOM, and interface issues in multiple systems, providing technical support to
    Engineering, IT, and Location personnel, and supporting the Release Manager and
    Configuration Engineering Manager as needed to maintain software functionality,
    quality, and conformance to business requirements.Essential Functions Creating
    new to company solutions to NPD, Process Engineering, IT, and Finance project
    requirements.Serve as SME in multiple systems - Sales Portal, Manufacturing RulesOracle,
    legacy - for internal team members external contacts.Function as Configuration
    Lead for major NPD or ERP projects.Creates and develops Config Engineering SOPs
    and systems.Collaborates with NPD, Product Management, Process Engineering, Supply
    Chain, Location personnel, Release Manager and Configuration Engineering Manager
    to understand, design and develop ERP product configuration code.Documents code
    development using Config Engineering SOPs and systems.Performs and documents unit
    and regression tests as directed by Release Manager.Monitors task assignments
    to support release readiness per Release Managers schedule.Minimum Qualifications
    Degrees, certifications, or technical training BABS in applicable major, or equivalent
    combination of education and directly applicable experience. Advanced Excel skills,
    knowledge of Engineering drawing practices, knowledge of manufacturing ERP systems
    practices, and knowledge of structured BOMs required.Minimum years of related
    experience 10 years of progressive experience, with at least 5 years of collaborative
    team experience in a customer-facing software environment. Fenestration industry
    experience is a strong plus.MITER Brands is an equal opportunity employer. MI
    Windows and Doors does not discriminate based on religion, race, creed, color,
    national origin, sex, age, disability, handicap, veteran status, sexual orientation,
    genetic information, or any other applicable legally protected category.
- source_sentence: Professional SummaryAccountant with more than 8 years accounting
    experience with profit making ,non for profit and non-governmental organizations
    (NGOs). Possess solid knowledge of GAAP, GASB and IFRS. Proficient in automated
    systems such as QuickBooks, Sun system and Peachtree Accounting. Core QualificationsGeneral
    Ledger AccountingBalance sheet account reconciliationBank Office Account reconciliationFinancial
    data analysisFinancial Statements Audit SupportGenerate various reportsAdjusting
    entries and periodic closingReview and monitoring of accounting eventFinancial
    Planning, Budgeting ReportingGrants ManagementContractual agreement and modificationDonor
    reportingMonitor and manage sub-granteeFund release for subsSystem improvement
    and recommendationsExternal Internal reportingProject closing Accounting Systems
    Sage Accounting, QuickBooks, Sun system , Peachtree Accounting and Mo.s.tPresentation
    Software Microsoft PowerPoint.Spreadsheets Advanced Excel with pivot tables, Lookups,
    references and Consolidation.Database Microsoft Access.Email Outlook and Lotus
    note Experience02 2015toAccountant Saint Louis,MO,Responsible for account coding
    accuracy Record, and reconcile Accounts Payables on a monthly basis Review and
    reconcile on-line corporate credit card transactions and documentation Actively
    participate in improvement of procedures and processes Review and report excess
    and obsolete inventory Prepare the invoices state and federal grant funders for
    reimbursable expenditures Prepare the invoices state and federal grant funders
    for reimbursable expenditures prepare 35 companies Bank reconciliation Accuracy
    of FIM tables (Financial Integration Module) Assist with preparation of budgets
    Provide status of financial condition by collecting, interpreting, and reporting
    financial data Prepare special reports by collecting, analyzing and summarizing
    Review all variances exceptions, explain and resolve Responsible for assisting
    with weekly monthly yearly closing activity Responsible for Journal Entries and
    General Ledger analysis Prepare internal reports regarding production, capacity
    and efficiencies Accounts payable and accounts receivable functions as directed
    Credit Card reconciliation All department processes and procedures documented
    and the appropriate individual(s) trained and cross-trained as necessary.01 2010to08
    2014Delegated Finance and Admin Manager and Finance OfficerAnova ,,EthiopiaPrepared
    standardize monthly, quarterly, biannual and annual finances and review overall
    financial reports and follow up financial status Over viewed Organization Finance
    and Administration as a delegate.Documented the process by which NGOs are selected
    for awards and notify applicants and other stakeholders of awards granted where
    open solicitations are sought Identified and assisted grantees in developing work
    plans, monitoring progress, tracking expenses, preparing reports, and facilitating
    grantees compliance with the terms of their agreements Conducted field visits
    to monitor grantees and provide on-site support with respect to financial grant
    management Collaborated with program staff to assist in developing and revising
    mechanisms for making payments and monitoring and reporting financial performance
    of sub-grantees Reviewed several grantee monthly financial reports, including
    invoices, budgets and up keeping databases Led a team through the entire process
    for sub grantees selection, from pre-award assessment to project closing Facilitated
    the processing of modification of sub-agreements, maintain and update grants contract
    document Followed-up contribution and recording of identified cost share expenses
    with sub-grantees Contributed to the development of grants management manual,
    materials, and resources Controlling and processing of Account Receivable , payable
    and Reconciling of account Ensured adherence to the organization s global financial
    policy, domestic financial procedures and guidelines related to disbursement activities,
    general accounts and grants Engaged in maintaining monthly and annual fixed asset
    inventory registration Ensured document tracking- paid stamp and filling are done
    in tact Ensured that financial transactions are recorded as per the chart of accounts
    and with proper source documents Reviewed and ensure the accuracy and quality
    of financial statements prepared Managed grant projects and fund release from
    donors control budget utilization Ensured that all financial documents and reports
    are well documented safely placed Facilitated internal and external audits and
    led development of action plans based on audit recommendations and monitored progress
    Led, supervised, guided and supported staff members, including accountant, cashier
    and storekeeper Participated in proposal budgeting when new projects are initiated.10
    2008to12 2009Senior AccountantExpedia ,,EthiopiaProduced periodic financial reports
    for both internal (organization) and external use (donors government) and interpret
    and analyze the reports and actual results against budgets and recommend program
    management team and budget holders Ensured that financial transactions are recorded
    as per chart of accounts with proper source documents Reviewed and initiated approval
    for disbursements including contracts and sub contacts payment Managed grant projects
    and fund release from donors control budget utilization Ensured that procurements
    are made per the organization procurement policy and Donor requirement Ensured
    that fixed assets registration and facilitated the annual inventory count Ensured
    bank reconciliation is made timely Reviewed payroll and ensure that government
    taxes are paid regularly and timely Controlled staff benefits like insurance,
    medical, PF etc.02 2007to09 2008AccountantAnova ,,EthiopiaEnsured that financial
    transactions are recorded as per the chart of accounts and with proper source
    documents Followed up annual budget cash flow Controlled the timely disbursement
    and settlement of different expenses Ensured that procurements are made as per
    procurement protocols Prepared checks and initiate bank reconciliation Prepared
    payroll and prepared income and other government tax payment Controlled petty
    cash and availability of cash on hand for daily activity Record financial transactions
    per World Vision chart of accounts document them Record grant projects financial
    activities expense settlement produce grant financial report Record fixed Assets
    per World Vision policies and facilitate annual inventory of project inventories
    Make ready financial documents for internal external audit. EducationExpected
    intotoMBA Degree Business Administration,,GPA Foundation for Academic Excellence,
    Ethiopia Completed 29 credits Business AdministrationExpected intotoB.A AccountingHaramaya
    University,,GPA Accounting SkillsAcademic, Account reconciliation, Accounting,
    accountant, Accounting Systems, Accounts payable, Accounts Payables, accounts
    receivable, Balance sheet, Bank reconciliation, benefits, Budgeting, budgets,
    budget, cash flow, cashier, closing, contracts, Credit, data analysis, databases,
    Database, documentation, Email, external audits, filling, Finance, Financial,
    Financial Planning, financial report, financial reports, Financial Statements,
    fixed Assets, General Ledger, General Ledger Accounting, government, Grants, Information
    Technology, insurance, inventory, Lotus, materials, Microsoft Access, Excel, Office,
    Outlook, Microsoft PowerPoint, payroll, Peachtree Accounting, pivot tables, policies,
    processes, procurement, program management, coding, progress, proposal, protocols,
    quality, QuickBooks, Reconciling, recording, reporting, requirement, Sage, Spreadsheets,
    Sun, tables, tax, taxes, Vision
  sentences:
  - Position Title Senior Construction Accountant (Req 116) Location Fresno, CA Date
    Posted 08082023 Pay Range 82,000 - 118,000 Position Description Job Summary Responsible
    for maintaining financial records and ensures that financial transactions are
    properly recorded. Verifies the accuracy of entries to ledger accounts and reconciles
    subsidiary ledger accounts to the general ledger. Prepares complex balance sheets,
    profit and loss statements, and other financial reports. Analyzes current costs,
    revenues, financial commitments, and obligations incurred to predict future revenues
    and expenses. Essential Duties and Responsibilities Essential duties and other
    responsibilities include but are not limited to the following Ensures accurate
    and timely reporting of all financial data in accordance with GAAP.Monitors revenue
    and expenses while coordinating collection, consolidation, and review of all financial
    data.Verifies the accuracy of all job costs as well as reconciling all subsidiary
    ledgers to the general ledger. This includes accounts payable and receivable,
    cash management, equipment and payroll.Prepares monthly and annual reports on
    expenditures and implementing corrective actions when necessary.Prepares monthly
    Work in Progress Schedules.Develops and maintains systems of control for accounting
    transactions.Creates, audits, and maintains effective chart of accounts and ensure
    costs are coded accurately.Performs monthly closing of all assigned accounts ensuring
    detailed and accurate reconciliations are documented and filed for all balance
    sheet and income statement accounts.Manages expense allocations from various departments
    and ensures accurate account coding.Obtains and maintains a thorough understanding
    of the financial reporting and general ledger structure.Manages all aspects of
    financial and accounting systems and processes including compliance, AP, AR and
    revenue accounting, payroll, fixed assets and general ledger functions, and internal
    financial reporting.Supports audit requirements including internal, external,
    and compliance audits.Assists with special projects as requested by Controller
    and CFO.Assists the accounting department and outside vendors to ensure financial
    accuracy, cost control and reporting.Preserves confidentiality of sensitive information.
    Position Requirements Qualifications To perform this job successfully, an individual
    must be able to perform each essential duty satisfactorily. The requirements listed
    below are representative of the knowledge, skill, and ability required. Required
    Education and Experience A Bachelors degree with an emphasis in Accounting. 7-10
    years of professional accounting experience within the construction industry.
    Ability to identify and resolve complex issues. Advanced knowledge of Microsoft
    Office (Word, Excel, and Outlook). Knowledge of Viewpoint Construction Software
    Excellent oral and written communication skills. Certificates, Licenses, Registrations
    A valid California Drivers License Physical requirements Physical Demands The
    physical demands described here are representative of those that must be met by
    an employee to successfully perform the essential functions of this job. While
    performing the duties of this Job, the employee is regularly required to use hands
    to finger, handle, or feel reach with hands and arms and talk and hear. The employee
    is occasionally required to stand and walk. The employee must occasionally lift
    andor move up to 10 pounds. Specific vision abilities required by this job include
    close vision, distance vision, depth perception and ability to adjust focus. Work
    Environment The work environment characteristics described here are representative
    of those an employee encounters while performing the essential functions of this
    job. Office Environment The noise level in the work environment is usually moderate.
    This job description is not designed to cover or contain a comprehensive listing
    of activities, duties or responsibilities that are required of the employee for
    this job. Duties, responsibilities and activities may change at any time with
    or without notice. Reasonable accommodations may be made to enable individuals
    with disabilities to perform the essential functions of the position.
  - A Senior Software Engineer at O Reilly Auto Parts develops and supports applications
    for internal and external systems including Inventory, Supply Chain, eCommerce,
    Retail Applications, Enterprise Search and more. Our teams are focused on the
    development, design and integration of various software systems, databases, and
    third-party packages utilizing tools and technologies including Java, JavaScript,
    Spring, Hibernate, and SQL. This particular position will be a full stack role
    working on Warehouse Management Applications however, we will consider anyone
    with Supply Chain Application Development experience. The base salary for this
    position is 116,000- 145,000 annually plus a 10 Annual Bonus. Exact compensation
    will be determined based on experience, however mid point around 126,000 - 131,000
    would be more practical. What You ll Do Partner with key stakeholders to develop
    new features and enhance and support existing applications and programs.Work with
    business systems analysts and stakeholders to translate business to technical
    requirements and problem solve.Collaborate with project teams and cross functional
    teams to troubleshoot open issues and bug-fixes.Collaborate, coach and mentor
    team members on best practices, code reviews, internal tools, and process improvements.Write
    and maintain readable, sustainable, and efficient code in highly optimized and
    scalable architectures.Own applications from conception and design, to implementation
    and support.Debug and test code as needed.Create and update advanced technical
    documentation. Skills and QualificationsRequired High School diploma or equivalent.10
    years of software development experience.Strong knowledge of software engineering
    best practices of the full software development life cycle, including coding standards,
    code reviews, source control, testing, build and release engineering processes
    with focus on automation and end to end traceability.Experience in Java, Spring
    Boot, SQL Databases, and HibernateWorking understanding of databases including
    writing and amending queries in Oracle, SQL, PostgreSQL andor NoSQL.Experience
    working in DevOps including continuous integration and continuous deployment using
    open source technologies like GIT, Jenkins, JIRA and Confluence.Experience in
    effectively communicating with a broad base of end users and multiple management
    layers, including the ability to interact with vendors as needed.Ability to lead
    and mentor junior developer and effectively communicate with members of the team.Ability
    to work flexible schedule including nightsweekends. Desired Bachelor s degree
    in computer science or equivalent experience.Ability to articulate advanced technical
    concepts and teach others.Experience working with AgileScrum methodology.Experience
    in Microservice Architecture, Kubernetes, Containerization, MongoDB, SOLRExperience
    working in a remote, virtual or work-from-home environment. Location Remote, USA
    - This role can be remote, virtual or work-from-home anywhere in the United States.
    About UsO Reilly Auto Parts IT department provides services to our corporate office,
    6000 stores, 28 distribution centers and 85,000 team members.We have over 900
    IT team members supporting 250 small, medium and large web and software applications
    in addition to third party packages.We provide a collaborative environment and
    encourage knowledge sharingWe respect a healthy work-life balanceOur teams keep
    open communication through video conferencing, team messaging and daily stand-upsOur
    leadership values collaboration and encourages team members to bring creative
    problem-solving ideas from both a technical and functional perspectiveWe have
    several career paths, whether you want to be an individual contributor, manager,
    project manager, or stay technical - there s a documented growth plan to help
    you follow the path you chooseWe want to grow our people - we help to make you
    better by providing training for both technical and professional development
  - Hello,Greetings from DevCare SolutionsI got an Opening with our direct client
    in Michigan Need Only Local to Michigan Candidate 100 placement Position Job title
    Business AnalystLocation Lansing, MIDuration 1 YearsInterview mode Ms. Teams Responsibilities
    Minimum of 12 years of general BA experience Minimum of 7 years conducting business
    process review and requirements elicitation and documentation Minimum of 5 years
    facilitating executive and diverse groups to topic consensus on complex and competing
    perspectives Minimum of 5 years providing strategic analysis and support to program,
    division and agency equivalent initiatives Minimum of 3 years with Agile Scrum,
    use of JIRA, user story developmentvalidation, sprint planning and backlog grooming
    Minimum of 2 years with contract compliance and contract change notices, specific
    to requirements specifications Minimum of 2 years practicing LEAN principals and
    supporting LPI initiatives Minimum of 1 year working with programs governed by
    state andor federal regulations Thanks Regards, Monisha Gunasekaran IT Technical
    Recruiter 470 523 - 8108 (Direct) monishag devcare.com
- source_sentence: Professional SummaryHighly skilled software development professional
    bringing more than 4 years in software design, development and integration. Offering
    advanced knowledge of cloud components, data ingestion, and Java Python JavaScript
    programming languages. SkillsPython, Java, HTML, CSS, JavaScript Application Frameworks
    GCP BigQuery, Pub Sub, Apache Beam, k8s, Stackdriver, Grafana, Tableau, Sumo Logic,
    DataDog, New Relic, Apigee, Angular, Node.js, Spring, Spring MVC, Spring Boot,
    Spring Data, Spring Cloud, Netflix OSS,JPA, Maven, Tomcat, Hibernate, Express,
    Redis, PostgreSQL, MongoDB, Docker, RESTful API, Nginx, TensorFlow, NLP,React,
    Git, Apache Bench, PostmanApacheAPICookingCSSDatabaseDebuggingDeliveryEngineerETLFunctionalGCPHTMLJavaJavaScriptLeadershipLogicDirectorMarketMongoDBMVCNLPOSSPostgreSQLPricingProgrammingProgressPythonQualityExpressReal-timeSoftware
    developersTableauTablesTomcatWorkshops Work HistorySoftware Developer,12 2018-CurrentMaxar
    Technologies Ltd Reston,VA,Designed and deployed the first data ingestion pipeline
    on Google Cloud Platform (GCP) by using Cloud Pub Sub, Cloud Dataflow, Cloud DataPrep,
    BigQuery, and Stackdriver to collect, store and monitor event data streaming The
    ingestion pipeline helps data scientist team on collecting the order level data
    events, IoT devices status without touching production database and support real-time
    data collecting Designed and implemented ingestion service and schemas store by
    using TypeScript The ingestion service and schemas store helped the entire team
    automatic generating unpacking pipeline and secondary table for all internal consumers
    Designed and implemented JavaScript SDK ingest URL to publish events from backend
    service, IoT devices, and 3rd party service Using JWT token as Authorization,
    Apigee as API key management tool Collaborated with data scientists team to collect
    requirements of demand prediction models and delivered ETL tables by using BigQuery
    Apache Beam(dataflow) and Cloud Dataprep Supported 2 data scientist engineer team,
    4 ML models including order preparation, dynamic pricing, etc Implemented KPI
    dashboards for cross-functional leadership to monitor data growth weekly and for
    4-5 teams of data scientists to monitor data ingestion and data quality daily.Used
    Tableau and Grafana to build data models and visualize data hosting millions of
    daily data entries Led a team of 4 software developers to collect user requirements
    from the factory operations team, translated the business to technology need to
    the services team and ensured consensus, spearheaded the build of Grafana dashboard
    to track time-series metrics from IoT device.The dashboard was used by the factory
    team to monitor progress and by the cross-functional data scientist team to build
    on models Built IoT device alerting and monitoring system prototypes by ingesting
    data, customizing Apache Beam job to run and normalize data, and created real-time
    alerting functions with zero delay collaborated with 2 PMs to understand user
    requirements, owned the end-to-end prototype build in 2 weeks, demoed in front
    of 10 director-level board members Decoupled and migrated the monolithic backend
    service to microservices by using Node.js, RESTful API Designed and implemented
    the Market microservice and database to support food cooking and delivery service
    by using PostgreSQL, Knex, RESTful API, Express.js, and Typescript Onboarded 100
    incoming software developers nationwide revamped and expanded knowledge transfer
    document, conducted workshops and 1 1s to help new joiners set up and understand
    environments, owned debugging and answered questions.Programmer,03 2016-12 2018New
    Jersey Institute Of Technology Newark,NJ,Designed and implemented an Auto-Test-System(ATS)
    handle the entire process including design, development, implementation, and integration
    Designed test packages (data checker, autographing tool, auto-input-data-file
    module, testing interface, and results checker) based on different standard requirements,
    ensure accuracy and sustainability of test results. EducationMaster of Science
    ,Expected in05 2014-Syracuse University-Syracuse,NYGPA Status-Bachelor of Science
    Electrical, Electronics Engineering Technologies,Expected in07 2011-Inner Mongolia
    University of Science Technology-,GPA Status- SkillsPython, Java, HTML, CSS, JavaScript
    AApplication Frameworks GCP BigQuery, Pub Sub, Apache Beam, k8s, Stackdriver,
    Grafana, Tableau, Sumo Logic, DataDDog, New Relic, Apigee, Angular, Node.js, Spring,
    Spring MVC, Spring Boot, Spring Data, Spring Cloud, Netflix OSS,JJPA, Maven, Tomcat,
    Hibernate, Express, Redis, PostgreSQL, MongoDB, Docker, RESTful API, Nginx, TensorFlow,
    NLP,RReact, Git, Apache Bench, Postman,Apache, API, cooking, CSS, database, debugging,
    delivery, engineer, ETL, functional, GCP, HTML, Java, JavaScript, leadership,
    Logic, director, Market, MongoDB, MVC, NLP, OSS, PostgreSQL, pricing, Programming,
    progress, Python, quality, Express, real-time, software developers, Tableau, tables,
    Tomcat, workshops
  sentences:
  - Position Senior Business Analyst (Production Support)Location Remote East CoastJob
    Type Direct Hire Job DescriptionThe Sr. Business Analyst elicits, analyzes, specifies,
    and validates the needs of business stakeholders. This includes understanding,
    documenting, and evaluating business processes through interviewing stakeholders.
    The Sr. Business Analyst elicits, gathers compiles and documents user requirements
    and translates them into functional requirements for technology solutions with
    an eye to improving processes and systems, enhancing their sustainability, and
    delivering maximum return on investment. The Sr. Business Analyst must have a
    thorough understanding of the business, functional, and technical aspects of the
    applications used within the portfolio they support. Core ResponsibilitiesEvaluate
    business processes anticipating requirements, uncovering areas for improvement,
    and eliciting requirements for change.Lead ongoing reviews of business processes
    and develop optimization strategies.Conduct interviews to gather user requirements
    via workshops, questionnaires, surveys, site visits, workflow storyboards, use
    cases, scenarios, and other methods.Prepare business cases which define potential
    benefits, options for achievingthese benefits through development of new or changed
    processes, and associated business risks.Assist with the interpretation of user
    requirements into feasible options and communicate this back to the business stakeholders.Prepare
    effort estimation.Perform requirements analysis. Document and Communicate the
    results of the analysis.Translate business requirements into functional requirements
    in a clear manner that is comprehensible to developersthe project team.Analyze
    and verify requirements for completeness, consistency, comprehensibility, feasibility,
    and conformity to standards.Develop and utilize standard templates to accurately
    and concisely write requirements specifications.Create process models, specifications,
    diagrams, and charts to provide direction to business owner(s), developers andor
    the project team.Develop and conduct peer reviews of the business requirements
    to ensure that requirement specifications are correctly interpreted.Select, adopt
    and adapt appropriate business analysis methods, tools and techniques selecting
    appropriately from predictive (plan-driven) approaches or adaptive (iterativeagile)
    approaches.Collaborate with stakeholders at all levels, conducting of investigations
    for strategy studies, business requirements specifications and feasibility studies.Provide
    leadership, training, coaching, and guidance to junior staff.Collaborate with
    ITS teams and business partners to evaluate and prioritize work.Triage and analyze
    incidents and problems. Provide clear analysis results including business impact.Assist
    test analyst(s) with testing duties as necessary.On-Call andor after-hours work
    required.Essential CompetenciesProfessionalismPersonal Accountability, Collaboration
    and Teamwork, Communication, Flexible and Adapts to Change, Service to Customers
    and Clients Skill QualificationsRequired Proven experience with business and technical
    requirements analysis, elicitation, modeling, verification, and methodology developmentExceptional
    analytical and conceptual thinking skillsAbility to influence stakeholders and
    work closely with them to determine acceptable solutionsExcellent documentation
    skillsFundamental analytical and conceptual thinking skillsExperience creating
    detailed reports and giving presentationsExcellent planning, organizational, and
    time management skillsAbility to create systematic and consistent requirements
    specifications in both technical and user-friendly languageExceptional analytical
    and statistical skills with the ability to apply them to systems issues and products
    as requiredAbility to translate business requirements of packaged solutionsAbility
    to research and understand packaged solution upgrades both minor and major. Translates
    the technical upgrade documentation into business terms the end-user can understand
    to make decision on. Makes recommendation on these upgrades.Experience in in Agile,
    Waterfall, and Hybrid environmentsUnderstanding of application development and
    software development life cycle conceptsEffectively participates in teams and
    moves the team toward completion of goalsSystemsTechnical Knowledge Basic Technical
    understanding of the digital platform, cloud applications, web services, server-side
    components and APIsData analysis skills including ability to perform ad hoc SQL
    queriesCompetency in Microsoft applications including Word, Excel, PowerPoint
    Visio and Outlook Education and Experience Qualifications Required BS or BA with
    emphasis in computer science, information systems or business administration7-10
    or more years related work experience as a business analystPreferred Certification
    of Competency in Business Analysis (CCBA) andor Certified Business Analysis professions
    (CBAP) preferred
  - Mada is a startup powering inspired shopping experiences. Our A.I.-based marketplace
    app, The Mada App, uses patented technology to recommend personalized and shoppable
    outfits for each user. Dubbed Tinder for Outfits, the app curates millions of
    products from thousands of brands and retailers, like Revolve, Bloomingdale s,
    Shopbop, Urban Outfitters, and more, to revolutionize the way Gen Z shops. Now,
    we are working with some of the worlds largest brands on a new venture, and are
    looking for an uber-talented full stack developer to join our team. As a Software
    Development Engineer for Mada, you will be at the forefront of our product development,
    contributing to both the front-end and back-end aspects of our applications. You
    will work collaboratively with a multidisciplinary team to design, develop, and
    deploy robust and scalable solutions. Your responsibilities will include iOS Application
    Development (Cordova JavaScript) Design, develop, and maintain iOS applications
    using the Cordova framework and JavaScript.Create responsive and user-friendly
    interfaces for an exceptional mobile experience.Collaborate with UXUI designers
    to ensure seamless integration of design elements.Troubleshoot and optimize iOS
    applications for performance and user satisfaction.PHP Application Development
    (Laravel) Develop server-side applications using PHP and the Laravel framework.Build
    and optimize APIs for smooth communication between front-end and back-end systems.Implement
    data storage solutions, integrate third-party services, and manage databases.Ensure
    the security and scalability of PHP applications.React Front-end Development Develop
    interactive and dynamic user interfaces using React and related technologies.Collaborate
    with designers to implement responsive and visually appealing designs.Integrate
    with back-end APIs to fetch and display data seamlessly.DevOps and Infrastructure
    Utilize Docker to containerize applications and streamline deployment processes.Ensure
    the reliability, availability, and scalability of our applications through efficient
    DevOps practices.Manage infrastructure and implement continuous integration and
    continuous deployment (CICD) pipelines.Additional Responsibilities Apply strong
    object-oriented programming principles (OOP) and utilize data structures effectively.Contribute
    to web development tasks and collaborate on back-end and front-end features.Leverage
    knowledge of Elastic Search for efficient data retrieval and manipulation.Collaborate
    on cross-functional projects and provide technical expertise. Our ideal candidate
    Bachelors degree in Computer Science, Software Engineering, or related field and
    3-5 years of relevant work experience.Masters degree in Computer Science, Software
    Engineering, or related field and 2-4 years of relevant work experience.Proficiency
    in Cordova, JavaScript (React) and PHP (Laravel)Strong understanding of full stack
    development, including front-end and back-end technologies.Experience with Docker,
    CICD pipelines, and infrastructure management.Knowledge of Elastic Search, OOP,
    and data structures.Additional proficiency in Python is a plus.Excellent problem-solving
    abilities and a proactive approach to troubleshooting.Effective communication
    skills and the ability to work collaboratively in a dynamic environment.Candidates
    should embrace change, take on diverse roles, and be excited about learning new
    skills as the company evolves.Ideal candidates are self-starters who proactively
    solve problems, drive projects forward independently, and identify opportunities
    for improvement.Being resourceful in overcoming challenges within limited resources
    is vital, while an entrepreneurial mindset fosters calculated risk-taking and
    contributions to the companys growth.
  - Net2Source Inc. is an award-winning total workforce solutions company recognized
    by Staffing Industry Analysts for our accelerated growth of 300 in the last 3
    years with over 5500 employees globally, with over 30 locations in the US and
    global operations in 32 countries. We believe in providing staffing solutions
    to address the current talent gap Right Talent Right Time Right Place Right Price
    and acting as a Career Coach to our consultants. Role Basel Business AnalystLocation
    Washington, D.C.Work Mode HybridHire Type 6 Month Contract (extendable) JD Role
    Specific Experience 6 years of relevant technical and business work experience
    The Candidates who have worked on Basel related projects in Credit risks or at
    least are aware of credit risk. Banking Financial domain experience, along with
    knowledge of risk management, familiarity with concepts of finance and accounting
    Proficiency in MS Excel Experience in defining and implementing technology solutions
    for a major financial institution Extensive experience as a Business Analyst for
    a large financial institution Extensive experience in gathering business requirements
    and developing functional specifications with special emphasis on use cases, defining
    test cases, and providing user training and support Extensive experience with
    various system development lifecycle methodologies and tailoring the artifacts
    to those methodologies Solution-oriented, detailed-focused, showing strong analytical
    and organization skills Familiarity with relational databases RDMS Experience
    with writing simple SQL statements (mostly SELECT with aim to analyze datasets)
    Regards,Prashant SinghSr. Account Manager - Enterprise BusinessNet2Source Inc.prashant.singh
    net2source.comDirect (201) 285-5087 Board (201) 340-8700 Ext. 509 Fax (201) 221-8131Corp.
    HQs 317 George St., Suite 220, New Brunswick, NJ 08901LinkedIn https www.linkedin.cominprashant-singh-b1b23526Website
    www.net2source.com Why work with us - At Net2Source, we believe everyone has an
    opportunity to lead. We see the importance of your perspective and your ability
    to create value. We want you to fit inwith an inclusive culture, focus on work-life
    fit and well-being, and a supportive, connected environment but we also want you
    to stand outwith opportunities to have a strategic impact, innovate, and take
    necessary steps to make your mark. We help clients with new skilling, talent strategy,
    leadership development, employee experience, transformational change management
    and beyond. Equal Employment Opportunity Statement Net2Source is an Equal Opportunity
    Employer. We believe that no one should be discriminated against because of their
    differences, such as age, disability, ethnicity, gender, gender identity and expression,
    religion or sexual orientation. Our rich diversity makes us more innovative, more
    competitive, and more creative, which helps us better serve our clients and our
    communities. All employment decisions shall be made without regard to age, race,
    creed, color, religion, sex, national origin, ancestry, disability status, veteran
    status, sexual orientation, gender identity or expression, genetic information,
    marital status, citizenship status or any other basis as protected by federal,
    state, or local law. Awards and Accolades America s Most Honored Businesses (Top
    10 )Awarded by USPAAC for Fastest Growing Business in the US12th Fastest Growing
    Staffing Company in USA by Staffing industry Analysts in the US (2020, 2019, 2020)Fastest
    50 by NJ Biz (2020, 2019, 2020)INC 5000 Fastest growing for 8 consecutive years
    in a row (only 1.26 companies make it to this list)Top 100 by Dallas Business
    Journal (2020 and 2019)Proven Supplier of the Year by Workforce Logiq (2020 and
    2019)2019 Spirit of Alliance Award by Agile12018 Best of the Best Platinum Award
    by Agile12018 TechServe Alliance Excellence Awards Winner2017 Best of the Best
    Gold Award by Agile1(Act1 Group)
- source_sentence: ProfileActively seeking full time opportunities in computer engineering
    to build a career in engineering industry and to work with a leading corporate
    hi-tech environment along with a team of committed dedicated people. Core QualificationsProgramming
    skills C C , MATLAB, Java. Verilog, MIPS, Python,Linux Software skills Eclipse,
    Net Beans, E-Tap, AutoCAD, Quartus, Open stack, Open Nebula, Open MP, Putty, Docker,
    Mininet, MS Office. Equipment used Oscillator, Logic analyze, Signal generator,
    Ubuntu, Virtual Box, VMware. Networking Protocols - TCP IP, UDP,IPv4,Ipv6,EIGR,DNS,VPN,SDN,MPLS,BGP,OSPF,ARP,DHCP,MPLS,SNMP,.
    EducationSouthern Methodist UniversityDallas,TXExpected inMay 2017 Bobby B. Lyle
    school of Engineering Grad -GPA ,Expected in M.S Computer Engineering-GPA Computer
    Engineering 3.72 4.00Mumbai University,Expected inMay 2014 B.E Electrical Engineering-GPA
    Electrical Engineering Professional ExperienceOshkosh Corp.-Lab Student monitor
    Student Assistant,,08 2017-PresentActively monitor students.Organize schedules.Provide
    technical assistance for lab devices.Maintain order in study hall.Technical presenter
    in national -level competition Nirman 2014 February-2014 Paper Title Medium Voltage
    Circuit Breaker Simulator .Secretary of Electrical Engineers Students Association
    (EESA) Aug 12- May- 13.Led a team in planning executing the entire departmental
    fest Vidyut organized by EESA.A Member of Creative and the sponsorship committee
    for the college technical fest Vectors in the year 2012-2013.Was a Member of the
    organizing committee for blood donation camp organized in college by BOMBAY Hospital.Power
    Consultants-Trainee Electrical Engineer,,08 2017-02 2017Was responsible for relay
    settings for Electrical Equipment s used in the Substations and preparation of
    electrical drawing Using AutoCAD-2010 which includes one-line diagram, area classification,
    layout drawings, schematic, interconnection Diagram, detailed installation drawings,
    etc.for 200KV, 33KV, 11KV, 6.6KV, 3.3KV and 415V systems.Siemens LTD-Intern,,06
    2017-07 2017Build a Medium Voltage Circuit Breaker Simulator which was used for
    testing of the Panels in the absence of an actual Circuit Breaker.Engineering
    project .Process and Memory Management for an Operating System - Designed and
    implemented a simulated OS using Java for general process and memory management
    which included designing a Process Control Block (PCB) using doubly linked list
    and the scheduling algorithm scheduled the processes according to Shortest Job
    First, Non-preemptive Priority scheduling, First Cum First Serve and Round Robin
    algorithms.Memory management for the processes were implemented where each process
    was assigned a memory on the basis of first fit, best fit worst fit algorithms.Literature
    review on Comparison of various Encryption Algorithms for security of smart Cards
    - Presented a paper focusing on the security and reliability of smart card and
    the role of various encryption algorithms symmetric as well as the asymmetric
    algorithms and a comparison was made to determine which algorithm is better for
    data security in a constrained environment.Matrix Multiplication using Verilog
    - Implemented a circuit that will multiply a 3x4 matrix with its transpose using
    Verilog coding.Optimizing performance and security in Mobile Cloud Computing using
    ZKP and Two Fish Presented a paper which included Zero knowledge protocol as an
    authentication technique and analysis of two fish blowfish algorithms in terms
    of its speed of encryption and security when used in clone cloud.Current Challenges
    and Solutions in SDN Security and Traffic Measurement - Presented a paper on different
    methods to overcome security issues in SDN and analyzed different methods to measure
    traffic parameters with limited utilization of resources, high accuracy and low
    latency.Integer Multiplication - Using Verilog coding expanded the basic ALU to
    handle integer multiplication.Two 32 bits two complement numbers were chosen which
    on multiplication would provide a 64-bit output.Comparative Study for Denoising
    of Various Medical Image (MATLAB)s - Designed and presented a paper for image
    acquisition process.Noised images were considered for noise detection and the
    performance of each image were evaluated. SkillsAutoCAD, basic, BGP, C, C , Computer
    Networks, Encryption, Cryptography, designing, DHCP, DNS, Eclipse, drawing, Image
    Processing, Image, Java, Beans, layout, Linux, Logic, MATLAB, memory, Microprocessor,
    MS Office, Networking, OS, Operating System, organizing, OSPF, presenter, Process
    Control, processes, coding, Programming, Protocols, Python, scheduling, smart
    Cards, SNMP, System Design, TCP IP, technical assistance, Verilog, VPN
  sentences:
  - ARM GROUP is looking for a Senior Electrical Engineer for our growing Client located
    in Annapolis, Maryland. The candidate will be responsible for the management of
    the electrical staff, quality control, project management, and review of design
    and construction documents. Additionally, the candidate will assist with the process
    and instrumentation diagrams (P IDs), and instrumentation amp control implementation.
    Responsibilities of this position during the design and construction phases of
    projects include Power Distribution, Motor Control, PLC Control System, Control
    Panels, Lighting, Facility Conduit and Wiring DesignSchematic and Logic DevelopmentExtensive
    Knowledge and Implementation of the National Electric CodeWorking knowledge of
    AutoCADFacility Construction Document and Shop Drawing ReviewFacility Testing
    and Startup As a successful candidate you should have Minimum 6 years experience
    in Industrial Electrical Design, preferably in water and wastewater applicationProfessional
    Engineer license in Maryland or ability to obtainProject Management experienceQuality
    focus with attention to detail ARM Group LLC is an Equal Employment Opportunity
    Employer. All qualified applicants will receive consideration for employment without
    regard to race, color, religion, gender identity, sexual orientation, national
    origin, genetic information, sex, age, disability, veteran status, or any other
    legally protected basis. The ARM GROUP LLC welcomes and encourages applications
    from diverse candidates, including people with disabilities. Accommodations are
    available upon request for applicants taking part in all aspects of the selection
    process. Applicants for this position must be legally authorized to work in the
    United States.
  - Software Data Engineer (ScalaPython) Hybrid on-site in Chicago, IL - local candidates
    or those willing to relocate only! Proprietary Trading Firm is looking to grow
    their data engineering organization with two engineers. Please see the details
    for both profiles below 1. Software Engineer (ScalaPython)3 years experience programming
    in Scala andor Python Cloud data platform development and deployment using Infrastructure-as-CodeOperational
    dashboards to monitor data ingestion using Grafana, PrometheusOther technologies
    GitLab, Bitbucket, Jenkins, RDS, S3 2. Software Engineer (Scala)3 years experience
    programming in Python Large scale data platforms such a Spark, Kafka, Delta Lake
    Experience with ETL pipelines for batch and live streaming Other technologies
    EKSKubernetes, MSKKafka, Spark, Databricks, Flink This is an opportunity to work
    at a data-driven organization in Chicago, IL with a collaborative, growing department.
    Other benefits include Flexible hybrid work style - in office TuesThurs (downtown
    Chicago, IL)Competitive compensation structure with uncapped bonus potential Work
    with modern technologies, see the impact of your work on the direct businessInteract
    with all parts of the business such as Compliance, Quants and Trading. EOE Statement
    Specialist Staffing Group is an equal opportunity employer. All qualified applicants
    will receive consideration for employment without regard to race, color, religion,
    sex, sexual orientation, gender identity, national origin, disability, or veteran
    status. To find out more about Huxley please visit www.huxley.com
  - Skills - Cucumber BDD Selenium UI Automation Experience Excellent knowledge and
    experience in testing Financial Domain applications. Hands-on experience in Test
    Plan, Test Case, and Test Scenario development. Experience in creating data requests
    based on test cases and data mining.
pipeline_tag: sentence-similarity
library_name: sentence-transformers
metrics:
- pearson_cosine
- spearman_cosine
model-index:
- name: SentenceTransformer based on sentence-transformers/all-MiniLM-L6-v2
  results:
  - task:
      type: semantic-similarity
      name: Semantic Similarity
    dataset:
      name: resume jd val
      type: resume-jd-val
    metrics:
    - type: pearson_cosine
      value: 0.6182316203042584
      name: Pearson Cosine
    - type: spearman_cosine
      value: 0.5730424908879306
      name: Spearman Cosine
---

# SentenceTransformer based on sentence-transformers/all-MiniLM-L6-v2

This is a [sentence-transformers](https://www.SBERT.net) model finetuned from [sentence-transformers/all-MiniLM-L6-v2](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2). It maps sentences & paragraphs to a 384-dimensional dense vector space and can be used for semantic textual similarity, semantic search, paraphrase mining, classification, clustering, and more.

## Model Details

### Model Description
- **Model Type:** Sentence Transformer
- **Base model:** [sentence-transformers/all-MiniLM-L6-v2](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2) <!-- at revision 1110a243fdf4706b3f48f1d95db1a4f5529b4d41 -->
- **Maximum Sequence Length:** 256 tokens
- **Output Dimensionality:** 384 dimensions
- **Similarity Function:** Cosine Similarity
- **Supported Modality:** Text
<!-- - **Training Dataset:** Unknown -->
<!-- - **Language:** Unknown -->
<!-- - **License:** Unknown -->

### Model Sources

- **Documentation:** [Sentence Transformers Documentation](https://sbert.net)
- **Repository:** [Sentence Transformers on GitHub](https://github.com/huggingface/sentence-transformers)
- **Hugging Face:** [Sentence Transformers on Hugging Face](https://huggingface.co/models?library=sentence-transformers)

### Full Model Architecture

```
SentenceTransformer(
  (0): Transformer({'transformer_task': 'feature-extraction', 'modality_config': {'text': {'method': 'forward', 'method_output_name': 'last_hidden_state'}}, 'module_output_name': 'token_embeddings', 'architecture': 'BertModel'})
  (1): Pooling({'embedding_dimension': 384, 'pooling_mode': 'mean', 'include_prompt': True})
  (2): Normalize({})
)
```

## Usage

### Direct Usage (Sentence Transformers)

First install the Sentence Transformers library:

```bash
pip install -U sentence-transformers
```
Then you can load this model and run inference.
```python
from sentence_transformers import SentenceTransformer

# Download from the 🤗 Hub
model = SentenceTransformer("sentence_transformers_model_id")
# Run inference
sentences = [
    'ProfileActively seeking full time opportunities in computer engineering to build a career in engineering industry and to work with a leading corporate hi-tech environment along with a team of committed dedicated people. Core QualificationsProgramming skills C C , MATLAB, Java. Verilog, MIPS, Python,Linux Software skills Eclipse, Net Beans, E-Tap, AutoCAD, Quartus, Open stack, Open Nebula, Open MP, Putty, Docker, Mininet, MS Office. Equipment used Oscillator, Logic analyze, Signal generator, Ubuntu, Virtual Box, VMware. Networking Protocols - TCP IP, UDP,IPv4,Ipv6,EIGR,DNS,VPN,SDN,MPLS,BGP,OSPF,ARP,DHCP,MPLS,SNMP,. EducationSouthern Methodist UniversityDallas,TXExpected inMay 2017 Bobby B. Lyle school of Engineering Grad -GPA ,Expected in M.S Computer Engineering-GPA Computer Engineering 3.72 4.00Mumbai University,Expected inMay 2014 B.E Electrical Engineering-GPA Electrical Engineering Professional ExperienceOshkosh Corp.-Lab Student monitor Student Assistant,,08 2017-PresentActively monitor students.Organize schedules.Provide technical assistance for lab devices.Maintain order in study hall.Technical presenter in national -level competition Nirman 2014 February-2014 Paper Title Medium Voltage Circuit Breaker Simulator .Secretary of Electrical Engineers Students Association (EESA) Aug 12- May- 13.Led a team in planning executing the entire departmental fest Vidyut organized by EESA.A Member of Creative and the sponsorship committee for the college technical fest Vectors in the year 2012-2013.Was a Member of the organizing committee for blood donation camp organized in college by BOMBAY Hospital.Power Consultants-Trainee Electrical Engineer,,08 2017-02 2017Was responsible for relay settings for Electrical Equipment s used in the Substations and preparation of electrical drawing Using AutoCAD-2010 which includes one-line diagram, area classification, layout drawings, schematic, interconnection Diagram, detailed installation drawings, etc.for 200KV, 33KV, 11KV, 6.6KV, 3.3KV and 415V systems.Siemens LTD-Intern,,06 2017-07 2017Build a Medium Voltage Circuit Breaker Simulator which was used for testing of the Panels in the absence of an actual Circuit Breaker.Engineering project .Process and Memory Management for an Operating System - Designed and implemented a simulated OS using Java for general process and memory management which included designing a Process Control Block (PCB) using doubly linked list and the scheduling algorithm scheduled the processes according to Shortest Job First, Non-preemptive Priority scheduling, First Cum First Serve and Round Robin algorithms.Memory management for the processes were implemented where each process was assigned a memory on the basis of first fit, best fit worst fit algorithms.Literature review on Comparison of various Encryption Algorithms for security of smart Cards - Presented a paper focusing on the security and reliability of smart card and the role of various encryption algorithms symmetric as well as the asymmetric algorithms and a comparison was made to determine which algorithm is better for data security in a constrained environment.Matrix Multiplication using Verilog - Implemented a circuit that will multiply a 3x4 matrix with its transpose using Verilog coding.Optimizing performance and security in Mobile Cloud Computing using ZKP and Two Fish Presented a paper which included Zero knowledge protocol as an authentication technique and analysis of two fish blowfish algorithms in terms of its speed of encryption and security when used in clone cloud.Current Challenges and Solutions in SDN Security and Traffic Measurement - Presented a paper on different methods to overcome security issues in SDN and analyzed different methods to measure traffic parameters with limited utilization of resources, high accuracy and low latency.Integer Multiplication - Using Verilog coding expanded the basic ALU to handle integer multiplication.Two 32 bits two complement numbers were chosen which on multiplication would provide a 64-bit output.Comparative Study for Denoising of Various Medical Image (MATLAB)s - Designed and presented a paper for image acquisition process.Noised images were considered for noise detection and the performance of each image were evaluated. SkillsAutoCAD, basic, BGP, C, C , Computer Networks, Encryption, Cryptography, designing, DHCP, DNS, Eclipse, drawing, Image Processing, Image, Java, Beans, layout, Linux, Logic, MATLAB, memory, Microprocessor, MS Office, Networking, OS, Operating System, organizing, OSPF, presenter, Process Control, processes, coding, Programming, Protocols, Python, scheduling, smart Cards, SNMP, System Design, TCP IP, technical assistance, Verilog, VPN',
    'ARM GROUP is looking for a Senior Electrical Engineer for our growing Client located in Annapolis, Maryland. The candidate will be responsible for the management of the electrical staff, quality control, project management, and review of design and construction documents. Additionally, the candidate will assist with the process and instrumentation diagrams (P IDs), and instrumentation amp control implementation. Responsibilities of this position during the design and construction phases of projects include Power Distribution, Motor Control, PLC Control System, Control Panels, Lighting, Facility Conduit and Wiring DesignSchematic and Logic DevelopmentExtensive Knowledge and Implementation of the National Electric CodeWorking knowledge of AutoCADFacility Construction Document and Shop Drawing ReviewFacility Testing and Startup As a successful candidate you should have Minimum 6 years experience in Industrial Electrical Design, preferably in water and wastewater applicationProfessional Engineer license in Maryland or ability to obtainProject Management experienceQuality focus with attention to detail ARM Group LLC is an Equal Employment Opportunity Employer. All qualified applicants will receive consideration for employment without regard to race, color, religion, gender identity, sexual orientation, national origin, genetic information, sex, age, disability, veteran status, or any other legally protected basis. The ARM GROUP LLC welcomes and encourages applications from diverse candidates, including people with disabilities. Accommodations are available upon request for applicants taking part in all aspects of the selection process. Applicants for this position must be legally authorized to work in the United States.',
    'Skills - Cucumber BDD Selenium UI Automation Experience Excellent knowledge and experience in testing Financial Domain applications. Hands-on experience in Test Plan, Test Case, and Test Scenario development. Experience in creating data requests based on test cases and data mining.',
]
embeddings = model.encode(sentences)
print(embeddings.shape)
# [3, 384]

# Get the similarity scores for the embeddings
similarities = model.similarity(embeddings, embeddings)
print(similarities)
# tensor([[1.0000, 0.6471, 0.6114],
#         [0.6471, 1.0000, 0.4499],
#         [0.6114, 0.4499, 1.0000]])
```
<!--
### Direct Usage (Transformers)

<details><summary>Click to see the direct usage in Transformers</summary>

</details>
-->

<!--
### Downstream Usage (Sentence Transformers)

You can finetune this model on your own dataset.

<details><summary>Click to expand</summary>

</details>
-->

<!--
### Out-of-Scope Use

*List how the model may foreseeably be misused and address what users ought not to do with the model.*
-->

## Evaluation

### Metrics

#### Semantic Similarity

* Dataset: `resume-jd-val`
* Evaluated with [<code>EmbeddingSimilarityEvaluator</code>](https://sbert.net/docs/package_reference/sentence_transformer/evaluation.html#sentence_transformers.sentence_transformer.evaluation.EmbeddingSimilarityEvaluator)

| Metric              | Value     |
|:--------------------|:----------|
| pearson_cosine      | 0.6182    |
| **spearman_cosine** | **0.573** |

<!--
## Bias, Risks and Limitations

*What are the known or foreseeable issues stemming from this model? You could also flag here known failure cases or weaknesses of the model.*
-->

<!--
### Recommendations

*What are recommendations with respect to the foreseeable issues? For example, filtering explicit content.*
-->

## Training Details

### Training Dataset

#### Unnamed Dataset

* Size: 4,589 training samples
* Columns: <code>sentence_0</code>, <code>sentence_1</code>, and <code>label</code>
* Approximate statistics based on the first 100 samples:
  |          | sentence_0                                                                           | sentence_1                                                                           | label                                                          |
  |:---------|:-------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|:---------------------------------------------------------------|
  | type     | string                                                                               | string                                                                               | float                                                          |
  | modality | text                                                                                 | text                                                                                 |                                                                |
  | details  | <ul><li>min: 256 tokens</li><li>mean: 256.0 tokens</li><li>max: 256 tokens</li></ul> | <ul><li>min: 53 tokens</li><li>mean: 229.61 tokens</li><li>max: 256 tokens</li></ul> | <ul><li>min: 0.2</li><li>mean: 0.46</li><li>max: 0.9</li></ul> |
* Samples:
  | sentence_0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | sentence_1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | label              |
  |:---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:-------------------|
  | <code>SummarySeasoned Data Entry Operator with 5 years of experience building and maintaining electronic databases. Received and reviewed new written records, transcribed information into electronic databases, verified and validated new and previously-input data fields, prepared reports, and contributed to refinement of data entry protocols. Detail-oriented professional effecting useful, accurate databases. SkillsMeticulous Attention to DetailCertified in 10-KeyData TranscriptionAdministrative Support SpecialistAdvanced Clerical KnowledgeCollecting InformationProficient With Database Filing and Data ArchivingVerifying Data AccuracyWritten and Verbal Communication10-Key CertificationWorkflow ManagementData VerificationTime ManagementData ManagementService OrientedData ReviewData CompilationProject ManagementReport GenerationSelf-StarterMicrosoft OfficeMultitasking and PrioritizationSpreadsheet ManagementData EntryInformation StorageAdvanced MS Office Suite KnowledgeData ProcessingData Integri...</code> | <code>This is a W2 contract in Minneapolis, MN 55402.Bank is looking for a successful Data Analyst to support our Enterprise Data Governance (EDG) and Data Privacy and Protection (DPP) initiatives. This role will collaborate with the business line and technology groups. Primary responsibilities include Effectively work in matrixed team of Data Analysts, Project Managers and Business Analysts in support of a specific business andor regulatory need. Research and build a detailed understanding of the problem and related data assets in order to code the data processing and analysis. Light development coding Ensure that the data used follows the compliance, access management and control policies of the company while meeting the data governance requirements of the business. Work with technical groups to support the collection, integration, and retention of the data sources. Apply data visualization and summarization techniques to the analytical results. Interpret and communicate the results in a m...</code> | <code>0.235</code> |
  | <code>Career OverviewExperienced Data Analyst with extensive skill in Data Modelling, Analysis, and Reporting using SSMS, SSRS, Crystal Reports, and CRM applications. Detail-oriented professional with proficient technical documentation, and project management skills. Work ExperienceData Operations Analyst,10 2015to08 2016Addepar New York,NY,Contributed to the Development and Maintenance of data quality standards on Millennium a CRM application.Designed Excel Applications for automated processes using Excel Macro and Visual Basic Editor to analyze, evaluate processes, and improve divisional efficiency.Provided technical documentation for organizational reports and project designs.Delivered self-service reports through SSRS.Designed forms and edited reports using Crystal Reports.Generated the Fiscal Year Reports for the Annual Funds division by sorting, using aggregate functions, Pivot table and VLOOKUP formula in Excel.Data Analyst (Contract),2015to04 2015Saic Cape Canaveral,FL,Committed to m...</code> | <code>ROR Partners is a rapidly growing, client-driven digital marketing and data company. We offer proven marketing solutions to a variety of vertical industries on a nationwide basis. ROR is seeking a Principal Data Engineer to serve as a key data architect and team leader on our data engineering team. The successful candidate will have demonstrated deep understanding and passion for designing and implementing robust ETL and ELT data pipelines. Position is remote and reports to the VP, Engineering. Salary is 170K to 195K and is determined by factors such as location, experience, and expertise. What you will doBuild, maintain, and administer our Snowflake data warehouse using Data Build Tool (dbt)Implement and maintain data pipelines between various operational systems and our data warehouse using Python, Airflow and integration platformsCreate and maintain documentation of data architectureCollaborate with internal and external stakeholders to ensure that data requirements are addressedMen...</code> | <code>0.213</code> |
  | <code>Summary11 20 1989 collaborative project management. Hold a successful track record of multi-site manufacturing projects. Proficient when working and designing with industrial sensors. knowledge of a motor vehicle including maintenance. Looking for an opportunity to continue my professional career in a company with room for growth. SkillsAND COMPETENCIESWell versed in AC DC Theory.Experienced in troubleshooting electromechanical equipment.Educated in soldering best practices.Methodical approach to all tasks.Familiar with lean manufacturing and six sigma industrial standards.Ability and willingness to work in all weather conditions.Excellent customer facing and communication skills.Software programming.Strong decision-making skills and the ability to prioritize and planeffectively. ExperienceIndustrial Electrical Engineer,10 2014-12 2016Dlr Group San Francisco,CA,Design The Dish Manufacturing Plant in El Paso, TX remanufactures Set-Top Boxes to Manufacturing Project like new condition.At...</code> | <code>Perform and generate reports on all routine tests and testing activities. Troubleshoot manufacturing component problems to the lowest Line Replaceable Unit (LRU), and support during qualification tests. Execute tests according to test procedures and schematics. Redline test procedures as required. Demonstrate good working knowledge and experience with the use of computers, , data recorders, digital millimetres, various measurement instruments, pneumatichydraulic gauges. Reading and understanding of schematics and wire lists Technician safety awareness is critical and shall always be considered while performing or setting up for any type of test. Technician must understand and apply all applicable ALSTOM Safety Procedures located on the PRISMA database. Clearly document and report any anomaly or failure during test execution Responsible for learning curve and optimization of test execution and troubleshooting Accountable for test execution, Must have strong knowledge and comprehension o...</code> | <code>0.546</code> |
* Loss: [<code>CosineSimilarityLoss</code>](https://sbert.net/docs/package_reference/sentence_transformer/losses.html#cosinesimilarityloss) with these parameters:
  ```json
  {
      "loss_fct": "torch.nn.modules.loss.MSELoss",
      "cos_score_transformation": "torch.nn.modules.linear.Identity"
  }
  ```

### Training Hyperparameters
#### Non-Default Hyperparameters

- `per_device_train_batch_size`: 32
- `num_train_epochs`: 4
- `per_device_eval_batch_size`: 32
- `multi_dataset_batch_sampler`: round_robin

#### All Hyperparameters
<details><summary>Click to expand</summary>

- `per_device_train_batch_size`: 32
- `num_train_epochs`: 4
- `max_steps`: -1
- `learning_rate`: 5e-05
- `lr_scheduler_type`: linear
- `lr_scheduler_kwargs`: None
- `warmup_steps`: 0
- `optim`: adamw_torch_fused
- `optim_args`: None
- `weight_decay`: 0.0
- `adam_beta1`: 0.9
- `adam_beta2`: 0.999
- `adam_epsilon`: 1e-08
- `optim_target_modules`: None
- `gradient_accumulation_steps`: 1
- `average_tokens_across_devices`: True
- `max_grad_norm`: 1
- `label_smoothing_factor`: 0.0
- `bf16`: False
- `fp16`: False
- `bf16_full_eval`: False
- `fp16_full_eval`: False
- `tf32`: None
- `gradient_checkpointing`: False
- `gradient_checkpointing_kwargs`: None
- `torch_compile`: False
- `torch_compile_backend`: None
- `torch_compile_mode`: None
- `use_liger_kernel`: False
- `liger_kernel_config`: None
- `use_cache`: False
- `neftune_noise_alpha`: None
- `torch_empty_cache_steps`: None
- `auto_find_batch_size`: False
- `log_on_each_node`: True
- `logging_nan_inf_filter`: True
- `include_num_input_tokens_seen`: no
- `log_level`: passive
- `log_level_replica`: warning
- `disable_tqdm`: False
- `project`: huggingface
- `trackio_space_id`: None
- `trackio_bucket_id`: None
- `trackio_static_space_id`: None
- `per_device_eval_batch_size`: 32
- `prediction_loss_only`: True
- `eval_on_start`: False
- `eval_do_concat_batches`: True
- `eval_use_gather_object`: False
- `eval_accumulation_steps`: None
- `include_for_metrics`: []
- `batch_eval_metrics`: False
- `save_only_model`: False
- `save_on_each_node`: False
- `enable_jit_checkpoint`: False
- `push_to_hub`: False
- `hub_private_repo`: None
- `hub_model_id`: None
- `hub_strategy`: every_save
- `hub_always_push`: False
- `hub_revision`: None
- `load_best_model_at_end`: False
- `ignore_data_skip`: False
- `restore_callback_states_from_checkpoint`: False
- `full_determinism`: False
- `seed`: 42
- `data_seed`: None
- `use_cpu`: False
- `accelerator_config`: {'split_batches': False, 'dispatch_batches': None, 'even_batches': True, 'use_seedable_sampler': True, 'non_blocking': False, 'gradient_accumulation_kwargs': None}
- `parallelism_config`: None
- `dataloader_drop_last`: False
- `dataloader_num_workers`: 0
- `dataloader_pin_memory`: True
- `dataloader_persistent_workers`: False
- `dataloader_prefetch_factor`: None
- `dataloader_multiprocessing_context`: None
- `dataloader_in_order`: True
- `remove_unused_columns`: True
- `label_names`: None
- `train_sampling_strategy`: random
- `length_column_name`: length
- `ddp_find_unused_parameters`: None
- `ddp_bucket_cap_mb`: None
- `ddp_broadcast_buffers`: False
- `ddp_static_graph`: None
- `ddp_backend`: None
- `ddp_timeout`: 1800
- `fsdp`: None
- `fsdp_config`: None
- `deepspeed`: None
- `debug`: []
- `skip_memory_metrics`: True
- `do_predict`: False
- `resume_from_checkpoint`: None
- `local_rank`: -1
- `prompts`: None
- `batch_sampler`: batch_sampler
- `multi_dataset_batch_sampler`: round_robin
- `router_mapping`: {}
- `learning_rate_mapping`: {}
- `warmup_ratio`: None

</details>

### Training Logs
| Epoch  | Step | Training Loss | resume-jd-val_spearman_cosine |
|:------:|:----:|:-------------:|:-----------------------------:|
| 1.0    | 144  | -             | 0.4781                        |
| 1.3889 | 200  | -             | 0.5301                        |
| 2.0    | 288  | -             | 0.5436                        |
| 2.7778 | 400  | -             | 0.5601                        |
| 3.0    | 432  | -             | 0.5639                        |
| 3.4722 | 500  | 0.0420        | -                             |
| 4.0    | 576  | -             | 0.5730                        |


### Training Time
- **Training**: 6.5 minutes

### Framework Versions
- Python: 3.13.16
- Sentence Transformers: 5.7.0
- Transformers: 5.20.2
- PyTorch: 2.11.0+cu130
- Accelerate: 1.15.0
- Datasets: 4.8.5
- Tokenizers: 0.23.3

## Additional Resources

- [Training and Finetuning Embedding Models with Sentence Transformers](https://huggingface.co/blog/train-sentence-transformers): the end-to-end guide for training or finetuning Sentence Transformer models.
- [Introduction to Matryoshka Embedding Models](https://huggingface.co/blog/matryoshka): variable-size embeddings that can be truncated with minimal quality loss.
- [Binary and Scalar Embedding Quantization for Significantly Faster & Cheaper Retrieval](https://huggingface.co/blog/embedding-quantization): post-training compression of embedding vectors.
- [Multimodal Embedding & Reranker Models with Sentence Transformers](https://huggingface.co/blog/multimodal-sentence-transformers): use text, image, audio, and video models through the same API.
- [Training and Finetuning Multimodal Embedding & Reranker Models with Sentence Transformers](https://huggingface.co/blog/train-multimodal-sentence-transformers): train multimodal embedding models, with a Visual Document Retrieval walkthrough.

## Citation

### BibTeX

#### Sentence Transformers
```bibtex
@inproceedings{reimers-2019-sentence-bert,
    title = "Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks",
    author = "Reimers, Nils and Gurevych, Iryna",
    booktitle = "Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing",
    month = "11",
    year = "2019",
    publisher = "Association for Computational Linguistics",
    url = "https://arxiv.org/abs/1908.10084",
}
```

<!--
## Glossary

*Clearly define terms in order to be accessible across audiences.*
-->

<!--
## Model Card Authors

*Lists the people who create the model card, providing recognition and accountability for the detailed work that goes into its construction.*
-->

<!--
## Model Card Contact

*Provides a way for people who have updates to the Model Card, suggestions, or questions, to contact the Model Card authors.*
-->